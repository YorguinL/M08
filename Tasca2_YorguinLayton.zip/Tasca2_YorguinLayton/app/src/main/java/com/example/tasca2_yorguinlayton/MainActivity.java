package com.example.tasca2_yorguinlayton;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;

import android.graphics.LinearGradient;
import android.os.Bundle;
import android.util.Log;
import android.util.TypedValue;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.util.Random;

import static android.graphics.Color.rgb;

public class MainActivity extends AppCompatActivity {

    TextView marcador;
    Integer ValorMarcador = 0;
    Float size;
    Random nAleatori = new Random();
    ConstraintLayout cnsLayout;
    int r,g,b;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        marcador = findViewById(R.id.marcador);

        Button btnSuma = findViewById(R.id.btnSum);
        btnSuma.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ValorMarcador++;
                marcador.setText(String.valueOf(ValorMarcador));
            }
        });

        Button btnRestar = findViewById(R.id.btnRest);
        btnRestar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ValorMarcador--;
                marcador.setText(String.valueOf(ValorMarcador));

            }
        });

        Button btnAugmentar = findViewById(R.id.btnAug);
        btnAugmentar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                size =  marcador.getTextSize() + 5.f;
                marcador.setTextSize(TypedValue.COMPLEX_UNIT_PX, size);
                Log.d("Mida",Float.toString(size));
            }
        });

        Button btnDisminuir = findViewById(R.id.btnDis);
        btnDisminuir.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                size = marcador.getTextSize() - 5.f;
                marcador.setTextSize(TypedValue.COMPLEX_UNIT_PX, size);

            }
        });

        Button btnAmagar = findViewById(R.id.btnAmag);
        btnAmagar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                marcador.setVisibility(View.INVISIBLE);
            }
        });

        Button btnMostrar = findViewById(R.id.btnMost);
        btnMostrar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                marcador.setVisibility(View.VISIBLE);
            }
        });

        Button btnColorText = findViewById(R.id.btnColTx);
        btnColorText.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                r = nAleatori.nextInt(255);
                b = nAleatori.nextInt(255);
                g = nAleatori.nextInt(255);
                marcador.setTextColor((rgb(r,b,g)));
            }
        });

        Button btnColorFons = findViewById(R.id.btnColFn);
        btnColorFons.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                r = nAleatori.nextInt(255);
                b = nAleatori.nextInt(255);
                g = nAleatori.nextInt(255);
                cnsLayout = findViewById(R.id.consLayout);
                cnsLayout.setBackgroundColor(rgb(r,g,b));
            }
        });
    }
}
