package com.example.tasca2_yorguinlayton;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;

import android.graphics.LinearGradient;
import android.opengl.Visibility;
import android.os.Bundle;
import android.util.Log;
import android.util.TypedValue;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.util.Random;

import static android.graphics.Color.rgb;

public class MainActivity extends AppCompatActivity {

    TextView marcador;
    Integer valorMarcador = 0;
    Float size;
    Boolean visible = true;
    Random nAleatori = new Random();
    ConstraintLayout cnsLayout;
    int r,g,b;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        marcador = findViewById(R.id.marcador);
        cnsLayout = findViewById(R.id.consLayout);

        Button btnSuma = findViewById(R.id.btnSum);
        btnSuma.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                valorMarcador++;
                marcador.setText(String.valueOf(valorMarcador));
            }
        });

        Button btnRestar = findViewById(R.id.btnRest);
        btnRestar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                valorMarcador--;
                marcador.setText(String.valueOf(valorMarcador));

            }
        });

        Button btnAugmentar = findViewById(R.id.btnAug);
        btnAugmentar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                size =  marcador.getTextSize() + 5.f;
                marcador.setTextSize(TypedValue.COMPLEX_UNIT_PX, size);
                //Log.d("Mida",Float.toString(size));
            }
        });

        Button btnDisminuir = findViewById(R.id.btnDis);
        btnDisminuir.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                size = marcador.getTextSize() - 5.f;
                marcador.setTextSize(TypedValue.COMPLEX_UNIT_PX, size);

            }
        });

        Button btnAmagar = findViewById(R.id.btnAmag);
        btnAmagar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                marcador.setVisibility(View.INVISIBLE);
                visible = false;
            }
        });

        Button btnMostrar = findViewById(R.id.btnMost);
        btnMostrar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                marcador.setVisibility(View.VISIBLE);
                visible = true;
            }
        });

        Button btnColorText = findViewById(R.id.btnColTx);
        btnColorText.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                r = nAleatori.nextInt(255);
                b = nAleatori.nextInt(255);
                g = nAleatori.nextInt(255);
                marcador.setTextColor((rgb(r,b,g)));
            }
        });

        Button btnColorFons = findViewById(R.id.btnColFn);
        btnColorFons.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                r = nAleatori.nextInt(255);
                b = nAleatori.nextInt(255);
                g = nAleatori.nextInt(255);
                cnsLayout.setBackgroundColor(rgb(r,g,b));
            }
        });
    }

    @Override
    public void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putInt("ValorMarcador", valorMarcador);
        outState.putFloat("Size", size);
        outState.putBoolean("Visible", visible);
        outState.putInt("R", r);
        outState.putInt("B", b);
        outState.putInt("G", g);

    }

    @Override
    public void onRestoreInstanceState(Bundle savedInstanceState) {
        super.onRestoreInstanceState(savedInstanceState);

        if(savedInstanceState != null){
            valorMarcador = savedInstanceState.getInt("ValorMarcador");
            size = savedInstanceState.getFloat("Size");
            visible = savedInstanceState.getBoolean("Visible");
            r = savedInstanceState.getInt("R");
            b = savedInstanceState.getInt("B");
            g = savedInstanceState.getInt("G");

            marcador.setText(String.valueOf(valorMarcador));
            marcador.setTextSize(TypedValue.COMPLEX_UNIT_PX, size);
            if (!visible){
                marcador.setVisibility(View.INVISIBLE);
            }
            marcador.setTextColor((rgb(r,g,b)));
            // cnsLayout.setBackgroundColor(rgb(r,g,b));
        }
    }
}
